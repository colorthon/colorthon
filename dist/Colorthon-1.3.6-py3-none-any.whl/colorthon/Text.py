from .utils import Colors


class Color():
    red = Colors.Red
    green = Colors.Green
    blue = Colors.Cyan
    cyan = Colors.Cyan
    magenta = Colors.Magenta
    grey = Colors.Grey
    yellow = Colors.Yellow
    white = Colors.White
    reset = Colors.Reset
